#include <iostream>
#include <pqxx/pqxx>

#include "query_funcs.h"

using namespace std;
using namespace pqxx;

#ifndef _EXERCISER_
#define _EXERCISER_


void exercise(connection *C);


#endif //_EXERCISER_       
